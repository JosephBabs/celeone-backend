<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\Api\V1\{AcademyController, AgendaController, AlbumController, AppConfigController, AuthController, CantiqueController, ChannelController, ChurchHistoryController, CommentController, ConversationController, CreatorRequestController, CreatorStudioController, DocumentController, FirebaseExchangeController, FriendController, LiveSessionController, MediaUploadController, MemberCardController, MessageController, MobileReleaseController, NotificationController, PackageController, PageController, ParishController, ParishRegistrationController, PaymentController, PostController, ProfessionalProfileController, ProfessionalRequestController, ProfessionalServiceController, ProfessionalTicketController, QuizController, ReactionController, ReelController, ReportController, RestrictionAppealController, SocialActionController, SocketInternalController, SocketTokenController, SongController, StatusController, SubscriptionController, TvDeviceController, UserInterestController, VideoController, WeeklyThemeController};
use App\Http\Middleware\{AssignRequestId, EnsureAdmin};
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->middleware(AssignRequestId::class)->group(function (): void {
    Route::post('auth/register', [AuthController::class, 'register']);
    Route::post('auth/login', [AuthController::class, 'login']);
    Route::post('auth/firebase/exchange', FirebaseExchangeController::class);
    Route::post('internal/socket/authorize', [SocketInternalController::class, 'authorizeChannel'])->middleware('throttle:600,1');
    Route::post('internal/socket/sync', [SocketInternalController::class, 'sync'])->middleware('throttle:600,1');
    Route::middleware('auth:sanctum')->group(function (): void {
        Route::get('me', [AuthController::class, 'me']);
        Route::post('auth/logout', [AuthController::class, 'logout']);
        Route::post('socket/token', SocketTokenController::class);
        Route::get('feed', [PostController::class, 'index']);
        Route::apiResource('posts', PostController::class);
        Route::get('posts/{post}/comments', [CommentController::class, 'index']);
        Route::post('posts/{post}/comments', [CommentController::class, 'store']);
        Route::delete('comments/{comment}', [CommentController::class, 'destroy']);
        Route::put('posts/{post}/reaction', [ReactionController::class, 'upsert']);
        Route::delete('posts/{post}/reaction', [ReactionController::class, 'destroy']);
        Route::get('friends', [FriendController::class, 'index']);
        Route::post('friend-requests', [FriendController::class, 'request']);
        Route::post('friend-requests/{id}/accept', [FriendController::class, 'accept']);
        Route::post('follows', [SocialActionController::class, 'follow']);
        Route::delete('follows/{type}/{id}', [SocialActionController::class, 'unfollow']);
        Route::post('posts/{post}/save', [SocialActionController::class, 'savePost']);
        Route::delete('posts/{post}/save', [SocialActionController::class, 'unsavePost']);
        Route::post('{type}/{id}/view', [SocialActionController::class, 'view'])->whereIn('type', ['posts', 'reels', 'statuses']);
        Route::post('notifications/{id}/read', [SocialActionController::class, 'readNotification']);
        Route::post('notifications/read-all', [SocialActionController::class, 'readAll']);
        Route::post('uploads/presign', [MediaUploadController::class, 'presign']);
        Route::post('uploads/{id}/complete', [MediaUploadController::class, 'complete']);
        Route::get('conversations', [ConversationController::class, 'index']);
        Route::post('conversations/direct', [ConversationController::class, 'direct']);
        Route::get('conversations/{id}', [ConversationController::class, 'show']);
        Route::get('conversations/{conversation}/messages', [MessageController::class, 'index']);
        Route::post('conversations/{conversation}/messages', [MessageController::class, 'store']);
        Route::post('conversations/{conversation}/read', [MessageController::class, 'read']);
        $resources = ['reels' => ReelController::class, 'statuses' => StatusController::class, 'pages' => PageController::class, 'notifications' => NotificationController::class, 'agenda' => AgendaController::class, 'weekly-themes' => WeeklyThemeController::class, 'documents' => DocumentController::class, 'church-history' => ChurchHistoryController::class, 'channels' => ChannelController::class, 'videos' => VideoController::class, 'songs' => SongController::class, 'albums' => AlbumController::class, 'cantiques' => CantiqueController::class, 'youth/quizzes' => QuizController::class, 'academy/courses' => AcademyController::class, 'professionals' => ProfessionalProfileController::class, 'professional-services' => ProfessionalServiceController::class, 'professional-requests' => ProfessionalRequestController::class, 'professional-tickets' => ProfessionalTicketController::class, 'parishes' => ParishController::class, 'parish-registrations' => ParishRegistrationController::class, 'member-cards' => MemberCardController::class, 'packages' => PackageController::class, 'subscriptions' => SubscriptionController::class, 'payments' => PaymentController::class, 'live/sessions' => LiveSessionController::class, 'creator/drafts' => CreatorStudioController::class, 'creator/requests' => CreatorRequestController::class, 'tv/devices' => TvDeviceController::class, 'me/interests' => UserInterestController::class];
        foreach ($resources as $uri => $controller) Route::apiResource($uri, $controller)->parameters([basename($uri) => 'id']);
        Route::prefix('admin')->middleware(EnsureAdmin::class)->group(function (): void {
            Route::get('dashboard', [AdminController::class, 'dashboard']);
            Route::get('users', [AdminController::class, 'users']);
            Route::patch('users/{user}', [AdminController::class, 'updateUser']);
            Route::get('posts', [AdminController::class, 'posts']);
            Route::delete('posts/{post}', [AdminController::class, 'deletePost']);
            Route::get('firebase-schema', [AdminController::class, 'firebaseSchema']);
            Route::get('domains/{domain}', [AdminController::class, 'domain']);
            Route::patch('domains/{domain}/{id}', [AdminController::class, 'updateDomain']);
            Route::apiResource('reports', ReportController::class);
            Route::apiResource('restriction-appeals', RestrictionAppealController::class);
            Route::apiResource('app-config', AppConfigController::class);
            Route::apiResource('mobile-releases', MobileReleaseController::class);
        });
    });
});
