<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Api\V1\Concerns\ApiResponses;
use App\Models\User;
use App\Services\FirebaseTokenVerifier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class FirebaseExchangeController extends Controller
{
    use ApiResponses;

    public function __invoke(Request $request, FirebaseTokenVerifier $verifier)
    {
        $data=$request->validate(['id_token'=>'required|string','device_name'=>'nullable|string|max:120']);
        try { $identity=$verifier->verify($data['id_token']); }
        catch (\Throwable $e) { return $this->failure('UNAUTHENTICATED', 'Firebase identity could not be verified.', 401); }
        $uid=(string) ($identity['localId'] ?? '');
        if ($uid==='') return $this->failure('UNAUTHENTICATED', 'Firebase UID is missing.', 401);
        $user=DB::transaction(function () use ($uid,$identity): User {
            $user=User::where('legacy_firebase_uid',$uid)->orWhere('firebase_uid',$uid)->first();
            if (! $user && ! empty($identity['email'])) $user=User::whereRaw('lower(email)=?', [strtolower($identity['email'])])->first();
            if (! $user) $user=new User(['name'=>$identity['displayName'] ?? 'Cèlè One user','email'=>$identity['email'] ?? $uid.'@migrated.celeone.local','password'=>Str::random(64)]);
            $user->forceFill(['firebase_uid'=>$uid,'legacy_firebase_uid'=>$uid,'avatar_url'=>$identity['photoUrl'] ?? $user->avatar_url,'email_verified_at'=>($identity['emailVerified'] ?? false) ? now() : $user->email_verified_at])->save();
            return $user;
        });
        return $this->success(['user'=>$user,'access_token'=>$user->createToken($data['device_name'] ?? 'migrated-mobile')->plainTextToken,'token_type'=>'Bearer']);
    }
}
