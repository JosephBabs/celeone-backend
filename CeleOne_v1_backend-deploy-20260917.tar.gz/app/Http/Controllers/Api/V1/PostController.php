<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Api\V1\Concerns\ApiResponses;
use App\Models\Post;
use App\Services\Outbox;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class PostController extends Controller
{
    use ApiResponses;
    public function index(Request $request)
    {
        $limit=min(50,max(1,$request->integer('limit',20))); $query=Post::with(['user:id,name,avatar_url','page:id,name,avatar_url'])->latest('id');
        if($request->filled('cursor'))$query->where('id','<',(int)base64_decode((string)$request->input('cursor')));
        if($request->filled('author_id'))$query->where('user_id',$request->integer('author_id'));
        if($request->filled('page_id'))$query->where('page_id',$request->integer('page_id'));
        $rows=$query->limit($limit+1)->get();$more=$rows->count()>$limit;$items=$rows->take($limit)->values();
        return $this->page($items,$more?base64_encode((string)$items->last()->id):null,$more,$limit);
    }
    public function show(Post $post){return $this->success($post->load(['user:id,name,avatar_url','page:id,name,avatar_url','media','comments.user:id,name,avatar_url']));}
    public function store(Request $request,Outbox $outbox)
    {
        $data=$request->validate(['text'=>'nullable|string|max:30000','type'=>'nullable|string|max:50','audience'=>'nullable|in:public,friends,private','page_id'=>'nullable|exists:pages,id','media'=>'nullable|array|max:10','media.*.url'=>'required_with:media|url','media.*.type'=>'required_with:media|string|max:30']);
        $post=DB::transaction(function()use($data,$request,$outbox){$post=Post::create(['firebase_id'=>(string)Str::ulid(),'user_id'=>$request->user()->id,'page_id'=>$data['page_id']??null,'text_content'=>$data['text']??null,'post_type'=>$data['type']??'status','audience'=>$data['audience']??'public','status'=>'published']);foreach($data['media']??[] as $m)$post->media()->create(['user_id'=>$request->user()->id,'type'=>$m['type'],'url'=>$m['url'],'metadata'=>$m]);DB::table('post_metrics')->insertOrIgnore(['post_id'=>$post->id,'created_at'=>now(),'updated_at'=>now()]);$outbox->record('feed.item.created','post',(string)$post->id,['post_id'=>$post->id]);return $post;});
        return $this->success($post->load('media'),201);
    }
    public function update(Request $request,Post $post,Outbox $outbox){abort_unless($request->user()->id===$post->user_id||$request->user()->isAdmin(),403);$post->update($request->validate(['text_content'=>'sometimes|nullable|string|max:30000','audience'=>'sometimes|in:public,friends,private','status'=>'sometimes|string|max:30']));$outbox->record('feed.item.updated','post',(string)$post->id,['post_id'=>$post->id]);return $this->success($post->fresh());}
    public function destroy(Request $request,Post $post,Outbox $outbox){abort_unless($request->user()->id===$post->user_id||$request->user()->isAdmin(),403);$post->delete();$outbox->record('feed.item.removed','post',(string)$post->id,['post_id'=>$post->id]);return $this->success(['deleted'=>true]);}
}
