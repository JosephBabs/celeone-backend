<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Api\V1\Concerns\ApiResponses;
use App\Services\Outbox;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class MessageController extends Controller
{
    use ApiResponses;
    private function room(Request $r, string $id): object
    {
        $room = DB::table('chat_rooms')->where(fn($q) => $q->where('firebase_id', $id)->orWhere('id', ctype_digit($id) ? (int)$id : -1))->first();
        abort_unless($room && DB::table('chat_room_members')->where(['chat_room_id' => $room->id, 'user_id' => $r->user()->id])->exists(), 404);
        return $room;
    }
    public function index(Request $r, string $conversation)
    {
        $room = $this->room($r, $conversation);
        $limit = min(100, max(1, $r->integer('limit', 40)));
        $q = DB::table('chat_messages')->where('chat_room_id', $room->id)->orderByDesc('id');
        if ($r->filled('cursor')) $q->where('id', '<', (int)base64_decode((string)$r->input('cursor')));
        $rows = $q->limit($limit + 1)->get();
        $more = $rows->count() > $limit;
        $items = $rows->take($limit)->values();
        return $this->page($items, $more ? base64_encode((string)$items->last()->id) : null, $more, $limit);
    }
    public function store(Request $r, string $conversation, Outbox $o)
    {
        $room = $this->room($r, $conversation);
        $d = $r->validate(['client_id' => 'required|uuid', 'type' => 'nullable|string|max:30', 'text' => 'nullable|string|max:30000', 'reply_to_id' => 'nullable|integer|exists:chat_messages,id', 'metadata' => 'nullable|array']);
        $msg = DB::transaction(function () use ($r, $room, $d, $o) {
            $existing = DB::table('chat_messages')->where(['chat_room_id' => $room->id, 'client_id' => $d['client_id']])->first();
            if ($existing) return $existing;
            $id = DB::table('chat_messages')->insertGetId(['firebase_id' => (string)Str::ulid(), 'client_id' => $d['client_id'], 'chat_room_id' => $room->id, 'user_id' => $r->user()->id, 'body' => $d['text'] ?? null, 'message_type' => $d['type'] ?? 'text', 'reply_to_id' => $d['reply_to_id'] ?? null, 'metadata' => json_encode($d['metadata'] ?? []), 'created_at' => now(), 'updated_at' => now()]);
            DB::table('chat_rooms')->where('id', $room->id)->update(['updated_at' => now()]);
            DB::table('chat_room_members')->where('chat_room_id', $room->id)->where('user_id', '!=', $r->user()->id)->increment('unread_count');
            $message = DB::table('chat_messages')->find($id);
            $o->record('message.created', 'conversation', (string)$room->id, ['conversation_id' => $room->firebase_id ?: $room->id, 'message' => $message]);
            return $message;
        });
        return $this->success($msg, 201);
    }
    public function read(Request $r, string $conversation, Outbox $o)
    {
        $room = $this->room($r, $conversation);
        DB::table('chat_room_members')->where(['chat_room_id' => $room->id, 'user_id' => $r->user()->id])->update(['unread_count' => 0, 'last_read_at' => now(), 'updated_at' => now()]);
        $o->record('message.read', 'conversation', (string)$room->id, ['conversation_id' => $room->firebase_id ?: $room->id, 'user_id' => $r->user()->id, 'read_at' => now()->toISOString()]);
        return $this->success(['read' => true]);
    }
}
