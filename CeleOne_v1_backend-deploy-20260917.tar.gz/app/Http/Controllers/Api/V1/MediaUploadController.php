<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Api\V1\Concerns\ApiResponses;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class MediaUploadController extends Controller
{
    use ApiResponses;
    public function presign(Request $r)
    {
        $d = $r->validate(['file_name' => 'required|string|max:190', 'mime_type' => 'required|string|max:120', 'size_bytes' => 'required|integer|min:1|max:62914560']);
        $id = (string)Str::ulid();
        $ext = pathinfo($d['file_name'], PATHINFO_EXTENSION);
        $path = 'uploads/' . $r->user()->id . '/' . date('Y/m') . '/' . $id . ($ext ? '.' . $ext : '');
        $disk = Storage::disk(config('filesystems.default'));
        abort_unless(method_exists($disk, 'temporaryUploadUrl'), 501, 'Configured storage does not support signed uploads.');
        $signed = $disk->temporaryUploadUrl($path, now()->addMinutes(15), ['ContentType' => $d['mime_type']]);
        DB::table('upload_sessions')->insert(['public_id' => $id, 'user_id' => $r->user()->id, 'status' => 'pending', 'title' => $d['file_name'], 'data' => json_encode(['path' => $path, 'mime_type' => $d['mime_type'], 'size_bytes' => $d['size_bytes']]), 'created_at' => now(), 'updated_at' => now()]);
        return $this->success(['upload_id' => $id, 'path' => $path, 'upload' => $signed]);
    }
    public function complete(Request $r, string $id)
    {
        $row = DB::table('upload_sessions')->where(['public_id' => $id, 'user_id' => $r->user()->id])->first();
        abort_unless($row, 404);
        DB::table('upload_sessions')->where('id', $row->id)->update(['status' => 'complete', 'updated_at' => now()]);
        return $this->success(['upload_id' => $id, 'status' => 'complete', 'asset' => json_decode($row->data, true)]);
    }
}
