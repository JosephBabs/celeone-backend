<?php

namespace App\Http\Controllers\Api\V1;

class SubscriptionController extends DomainResourceController
{
    protected string $table='user_subscriptions';
}
