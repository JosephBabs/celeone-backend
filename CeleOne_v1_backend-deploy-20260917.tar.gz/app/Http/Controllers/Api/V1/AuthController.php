<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Api\V1\Concerns\ApiResponses;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    use ApiResponses;

    public function register(Request $request)
    {
        $data=$request->validate(['name'=>'required|string|max:120','email'=>'required|email|max:190|unique:users,email','password'=>'required|string|min:10|confirmed']);
        $user=User::create(['name'=>$data['name'],'email'=>strtolower($data['email']),'password'=>$data['password'],'role'=>'user']);
        return $this->success($this->tokens($user, $request), 201);
    }

    public function login(Request $request)
    {
        $data=$request->validate(['email'=>'required|email','password'=>'required|string','device_name'=>'nullable|string|max:120']);
        $user=User::whereRaw('lower(email)=?', [strtolower($data['email'])])->first();
        if (! $user || ! Hash::check($data['password'], $user->password)) {
            throw ValidationException::withMessages(['email'=>['Invalid credentials.']]);
        }
        return $this->success($this->tokens($user, $request));
    }

    public function me(Request $request) { return $this->success($request->user()); }

    public function logout(Request $request)
    {
        $request->user()?->currentAccessToken()?->delete();
        return $this->success(['logged_out'=>true]);
    }

    private function tokens(User $user, Request $request): array
    {
        $name=(string) ($request->input('device_name') ?: $request->header('X-Device-ID') ?: 'mobile');
        return ['user'=>$user,'access_token'=>$user->createToken($name)->plainTextToken,'token_type'=>'Bearer'];
    }
}
