<?php

namespace App\Http\Controllers\Api\V1;

class LiveSessionController extends DomainResourceController
{
    protected string $table='social_live_sessions';
}
