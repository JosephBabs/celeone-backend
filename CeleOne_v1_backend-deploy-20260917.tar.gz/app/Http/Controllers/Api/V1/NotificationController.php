<?php

namespace App\Http\Controllers\Api\V1;

class NotificationController extends DomainResourceController
{
    protected string $table='notification_inbox';
}
