<?php

namespace App\Http\Controllers\Api\V1;

class PackageController extends DomainResourceController
{
    protected string $table='subscription_packages';
}
