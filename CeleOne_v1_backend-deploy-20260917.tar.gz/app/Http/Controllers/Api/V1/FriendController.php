<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Api\V1\Concerns\ApiResponses;
use App\Services\Outbox;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class FriendController extends Controller
{
    use ApiResponses;
    public function index(Request $r)
    {
        return $this->success(DB::table('friendships')->where(fn($q) => $q->where('user_id', $r->user()->id)->orWhere('friend_id', $r->user()->id))->where('status', 'accepted')->get());
    }
    public function request(Request $r, Outbox $o)
    {
        $d = $r->validate(['user_id' => 'required|integer|exists:users,id|different:' . ($r->user()->id)]);
        $id = (string)Str::ulid();
        DB::table('friend_requests')->updateOrInsert(['public_id' => $id], ['user_id' => $r->user()->id, 'parent_type' => 'receiver', 'parent_id' => (string)$d['user_id'], 'status' => 'pending', 'data' => json_encode(['sender_id' => $r->user()->id, 'receiver_id' => $d['user_id']]), 'created_at' => now(), 'updated_at' => now()]);
        $o->record('friend.requested', 'user', (string)$d['user_id'], ['request_id' => $id, 'sender_id' => $r->user()->id]);
        return $this->success(['id' => $id, 'status' => 'pending'], 201);
    }
    public function accept(Request $r, string $id, Outbox $o)
    {
        $req = DB::table('friend_requests')->where('public_id', $id)->where('parent_id', (string)$r->user()->id)->first();
        abort_unless($req, 404);
        $data = json_decode($req->data, true);
        DB::transaction(function () use ($r, $req, $data, $o) {
            DB::table('friend_requests')->where('id', $req->id)->update(['status' => 'accepted', 'updated_at' => now()]);
            DB::table('friendships')->updateOrInsert(['user_id' => $data['sender_id'], 'friend_id' => $r->user()->id], ['status' => 'accepted', 'created_at' => now(), 'updated_at' => now()]);
            $o->record('friend.accepted', 'user', (string)$data['sender_id'], ['user_id' => $r->user()->id]);
        });
        return $this->success(['status' => 'accepted']);
    }
}
