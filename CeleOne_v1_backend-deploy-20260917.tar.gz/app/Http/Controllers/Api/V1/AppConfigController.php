<?php

namespace App\Http\Controllers\Api\V1;

class AppConfigController extends DomainResourceController
{
    protected string $table='app_configs';
}
