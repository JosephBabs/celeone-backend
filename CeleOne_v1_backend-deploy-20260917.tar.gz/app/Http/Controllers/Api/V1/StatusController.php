<?php

namespace App\Http\Controllers\Api\V1;

class StatusController extends DomainResourceController
{
    protected string $table='statuses';
}
