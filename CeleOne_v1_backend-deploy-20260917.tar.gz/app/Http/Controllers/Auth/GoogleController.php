<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Google\Client as GoogleClient;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class GoogleController extends Controller
{
    public function handleGoogleSignIn(Request $request): JsonResponse
    {
        $data = $request->validate(['idToken' => ['required', 'string']]);
        try {
            $client = new GoogleClient(['client_id' => config('services.google.mobile_client_id')]);
            $payload = $client->verifyIdToken($data['idToken']);
            abort_unless(is_array($payload) && !empty($payload['sub']) && !empty($payload['email']), 401, 'Invalid Google token.');
            $user = User::where('google_id', $payload['sub'])->orWhere('email', $payload['email'])->first();
            $user ??= new User(['email' => $payload['email']]);
            $user->fill(['name' => $user->name ?: ($payload['name'] ?? 'CeleOne user'), 'email' => $payload['email'], 'google_id' => $payload['sub'], 'avatar_url' => $user->avatar_url ?: ($payload['picture'] ?? null)])->save();
            return response()->json(['token' => $user->createToken('mobile-app')->plainTextToken, 'user' => $user]);
        } catch (\Throwable $exception) {
            Log::warning('Google authentication failed', ['message' => $exception->getMessage()]);
            return response()->json(['message' => 'Google authentication failed.'], 401);
        }
    }
}
