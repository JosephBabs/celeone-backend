<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    public function dashboard(): JsonResponse { return response()->json(['users' => User::count(), 'posts' => Post::count(), 'firebase_documents' => DB::table('firebase_documents')->count()]); }
    public function users(): JsonResponse { return response()->json(User::latest()->paginate(50)); }
    public function updateUser(Request $request, User $user): JsonResponse { $user->update($request->validate(['role' => ['required', 'in:user,admin,super_admin'], 'name' => ['sometimes', 'string', 'max:255']])); return response()->json($user); }
    public function posts(): JsonResponse { return response()->json(Post::with('user:id,name')->latest()->paginate(50)); }
    public function deletePost(Post $post): JsonResponse { $post->delete(); return response()->json(['success' => true]); }
    public function firebaseSchema(): JsonResponse { return response()->json(config('firebase_collections')); }
    public function domain(Request $request, string $domain): JsonResponse
    {
        $table = config('celeone_domains.collections.'.$domain, $domain);
        abort_unless(in_array($table, array_unique(array_values(config('celeone_domains.collections', []))), true), 404);
        return response()->json(DB::table($table)->orderByDesc('id')->paginate(min(100, max(1, $request->integer('limit', 50)))));
    }
    public function updateDomain(Request $request, string $domain, string $id): JsonResponse
    {
        $table = config('celeone_domains.collections.'.$domain, $domain);
        abort_unless(in_array($table, array_unique(array_values(config('celeone_domains.collections', []))), true), 404);
        $data = $request->validate(['status'=>'sometimes|nullable|string|max:50','title'=>'sometimes|nullable|string|max:255','body'=>'sometimes|nullable|string','data'=>'sometimes|array']);
        if (isset($data['data'])) $data['data'] = json_encode($data['data']);
        $data['updated_at'] = now();
        abort_unless(DB::table($table)->where('public_id', $id)->update($data), 404);
        return response()->json(DB::table($table)->where('public_id', $id)->first());
    }
}
