<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Api\V1\Concerns\ApiResponses;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\URL;

class MediaUploadController extends Controller
{
    use ApiResponses;

    public function presign(Request $request)
    {
        // Accept both the documented backend contract and the older RN storage
        // compatibility names so older app builds do not fail with HTTP 422.
        $request->merge([
            'file_name' => $request->input('file_name', $request->input('filename')),
            'mime_type' => $request->input('mime_type', $request->input('content_type')),
            'size_bytes' => $request->input('size_bytes', $request->input('size')),
        ]);
        $data = $request->validate([
            'file_name' => 'required|string|max:190',
            'mime_type' => 'required|string|max:120',
            'size_bytes' => 'required|integer|min:1|max:1073741824',
        ]);

        $id = (string) Str::ulid();
        $ext = strtolower(pathinfo($data['file_name'], PATHINFO_EXTENSION));
        abort_unless(in_array($ext, ['jpg','jpeg','png','webp','gif','heic','mp4','mov','m4v','webm','mp3','m4a','aac','wav','ogg','pdf','txt','doc','docx','xls','xlsx','ppt','pptx','zip'], true), 422, 'Unsupported file type.');
        $path = 'uploads/' . $request->user()->id . '/' . date('Y/m') . '/' . $id . ($ext ? '.' . $ext : '');
        $diskName = config('filesystems.default') === 'local' ? 'public' : config('filesystems.default');
        $disk = Storage::disk($diskName);
        $local = config('filesystems.disks.'.$diskName.'.driver') === 'local';
        $signed = $local ? ['url'=>URL::temporarySignedRoute('uploads.content', now()->addHours(2), ['id'=>$id]),'headers'=>['Content-Type'=>$data['mime_type']]] : $disk->temporaryUploadUrl($path, now()->addMinutes(30), ['ContentType' => $data['mime_type']]);
        $url = is_array($signed) ? ($signed['url'] ?? null) : $signed;
        $headers = is_array($signed) ? ($signed['headers'] ?? []) : [];

        DB::table('upload_sessions')->insert([
            'public_id' => $id,
            'user_id' => $request->user()->id,
            'status' => 'pending',
            'title' => $data['file_name'],
            'data' => json_encode(['path' => $path, 'disk'=>$diskName, 'mime_type' => $data['mime_type'], 'size_bytes' => $data['size_bytes']]),
            'created_at' => now()->toISOString(),
            'updated_at' => now()->toISOString(),
        ]);

        return $this->success([
            'id' => $id,
            'upload_id' => $id,
            'path' => $path,
            'method' => 'PUT',
            'upload_url' => $url,
            'headers' => $headers,
            'chunk_size' => $local ? 8388608 : null,
            'upload' => ['url' => $url, 'headers' => $headers, 'method' => 'PUT'],
            'public_url' => $this->publicUrl($path),
        ]);
    }

    public function complete(Request $request, string $id)
    {
        $row = DB::table('upload_sessions')->where(['public_id' => $id, 'user_id' => $request->user()->id])->first();
        abort_unless($row, 404);
        $asset = json_decode((string) $row->data, true) ?: [];
        $path = (string) ($asset['path'] ?? $request->input('path', ''));
        $disk=Storage::disk($asset['disk'] ?? (config('filesystems.default') === 'local' ? 'public' : config('filesystems.default')));
        abort_unless($disk->exists($path) && $disk->size($path)===(int)$asset['size_bytes'],422,'Upload is incomplete. Please retry.');
        DB::table('upload_sessions')->where('id', $row->id)->update(['status' => 'complete', 'updated_at' => now()->toISOString()]);
        $url = $path !== '' ? $this->publicUrl($path) : null;
        return $this->success([
            'id' => $id,
            'upload_id' => $id,
            'status' => 'complete',
            'path' => $path,
            'url' => $url,
            'asset' => array_merge($asset, ['url' => $url]),
        ]);
    }

    public function url(Request $request)
    {
        $path = $this->authorizedPath($request, (string) $request->query('path', ''));
        abort_unless($path !== '', 422, 'path is required.');
        return $this->success(['path' => $path, 'url' => $this->publicUrl($path)]);
    }

    public function destroy(Request $request)
    {
        $path = $this->authorizedPath($request, (string) $request->query('path', ''));
        abort_unless($path !== '', 422, 'path is required.');
        Storage::disk(config('filesystems.default') === 'local' ? 'public' : config('filesystems.default'))->delete($path);
        return $this->success(['deleted' => true, 'path' => $path]);
    }

    private function authorizedPath(Request $request, string $path): string
    {
        $path = ltrim(rawurldecode($path), '/');
        abort_if(Str::contains($path, ['..', '\\']), 422, 'Invalid upload path.');
        if (! $request->user()->isAdmin()) {
            abort_unless(Str::startsWith($path, 'uploads/' . $request->user()->id . '/'), 403, 'You do not own this upload.');
        }
        return $path;
    }

    private function publicUrl(string $path): string
    {
        return Storage::disk(config('filesystems.default') === 'local' ? 'public' : config('filesystems.default'))->url($path);
    }

    public function content(Request $request, string $id)
    {
        $row=DB::table('upload_sessions')->where('public_id',$id)->first();
        abort_unless($row && $row->status==='pending',404);
        $asset=json_decode($row->data,true);
        $disk=Storage::disk($asset['disk'] ?? 'public');
        abort_unless(config('filesystems.disks.'.($asset['disk'] ?? 'public').'.driver')==='local',422);
        $path=$disk->path($asset['path']);
        if (!is_dir(dirname($path))) mkdir(dirname($path),0755,true);
        $chunked=$request->hasHeader('X-Upload-Offset');
        $offset=$chunked ? (int)$request->header('X-Upload-Offset') : 0;
        abort_if($offset<0 || $offset>=(int)$asset['size_bytes'],422,'Invalid chunk offset.');
        $temporary=$path.'.part';
        $input=$request->getContent(true); $output=fopen($temporary,'c+b'); $bytes=0; $success=false; $writing=false;
        flock($output,LOCK_EX);
        try {
            $stored=fstat($output)['size'];
            abort_unless($stored===$offset,409,'Upload offset mismatch.');
            $writing=true;
            fseek($output,$offset);
            while (!feof($input)) {
                $chunk=fread($input,1024*1024);
                if ($chunk===false) throw new \RuntimeException('Upload read failed.');
                $bytes+=strlen($chunk);
                abort_if($bytes+$offset>(int)$asset['size_bytes'] || ($chunked && $bytes>8388608),413,'Upload exceeds declared size.');
                if (fwrite($output,$chunk)!==strlen($chunk)) throw new \RuntimeException('Upload write failed.');
            }
            fflush($output);
            if ($chunked && $bytes+$offset<(int)$asset['size_bytes']) {
                abort_unless($bytes>0,422,'Empty upload chunk.');
                $success=true;
                return response()->json(['uploaded'=>false,'bytes'=>$bytes+$offset]);
            }
            abort_unless($bytes+$offset===(int)$asset['size_bytes'],422,'Incomplete upload.');
            $mime=(new \finfo(FILEINFO_MIME_TYPE))->file($temporary);
            abort_if(in_array($mime,['text/html','application/x-httpd-php','application/x-executable','application/x-sharedlib'],true),422,'Unsupported file content.');
            rename($temporary,$path);
            $success=true;
            return response()->json(['uploaded'=>true,'bytes'=>$bytes+$offset]);
        } finally {
            if (is_resource($output)) { if (!$success && $writing) ftruncate($output,$offset); flock($output,LOCK_UN); fclose($output); }
            if (is_resource($input)) fclose($input);
        }
    }
}
