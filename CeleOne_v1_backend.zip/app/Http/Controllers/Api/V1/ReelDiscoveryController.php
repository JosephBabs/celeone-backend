<?php
namespace App\Http\Controllers\Api\V1;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use App\Services\Feed\FeedAudience;

class ReelDiscoveryController {
    public function __invoke(Request $r) {
        $input=$r->validate(['cursor'=>'nullable|string|max:4096','limit'=>'nullable|integer|min:1|max:50']);
        $state=['uid'=>$r->user()->id,'snapshot'=>(int)DB::table('firebase_documents')->max('id'),'expires'=>time()+7200,'after'=>null];
        if (!empty($input['cursor'])) {
            try { $state=json_decode(Crypt::decryptString($input['cursor']),true,512,JSON_THROW_ON_ERROR); }
            catch (\Throwable $e) { abort(422,'Invalid reel cursor.'); }
            abort_unless(($state['uid'] ?? null)===$r->user()->id && ($state['expires'] ?? 0)>time(),410,'Refresh reels.');
        }
        $audience=new FeedAudience($r->user());
        $q=$audience->query('reels')->where('id','<=',$state['snapshot'])
            ->whereRaw("(COALESCE(payload->>'videoUrl','') <> '' OR (jsonb_typeof(payload->'media')='array' AND payload->'media' <> '[]'::jsonb))");
        if ($state['after']) { [$time,$id]=$state['after']; $q->where(fn($q)=>$q->where('feed_created_at_ms','<',$time)->orWhere(fn($q)=>$q->where('feed_created_at_ms',$time)->where('document_id','<',$id))); }
        $limit=$input['limit'] ?? 30;
        $rows=$q->orderByDesc('feed_created_at_ms')->orderByDesc('document_id')->limit($limit+1)->get();
        $selected=$rows->take($limit); $more=$rows->count()>$limit;
        if ($last=$selected->last()) $state['after']=[(int)$last->feed_created_at_ms,$last->document_id];
        $items=$selected->map(function($row) use($audience) {
            $d=json_decode($row->payload,true) ?: [];
            return array_merge($d,['id'=>$row->document_id,'reelId'=>$row->document_id,'type'=>'reel','authorId'=>$d['authorId'] ?? $row->feed_author_id,'createdAtMs'=>(int)$row->feed_created_at_ms,'feedReason'=>$audience->reason($row)]);
        })->values();
        return response()->json(['items'=>$items,'hasMore'=>$more,'nextCursor'=>$more ? Crypt::encryptString(json_encode($state)) : null]);
    }
}
