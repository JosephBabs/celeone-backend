<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Api\V1\Concerns\ApiResponses;
use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Services\Outbox;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReactionController extends Controller
{
    use ApiResponses;

    public function show(Request $request, string $post)
    {
        $record = $this->post($post);
        $publicId = (string) ($record?->firebase_id ?: $post);
        $actorId = $this->actorId($request);
        $mirror = DB::table('firebase_documents')->where([
            'collection_path' => 'posts/' . $publicId . '/reactions',
            'document_id' => $actorId,
        ])->first();
        $reaction = $mirror ? ($this->payload($mirror)['reaction'] ?? 'like') : null;
        if (! $reaction && $record) {
            $reaction = DB::table('reactions')->where(['post_id' => $record->id, 'user_id' => $request->user()->id])->value('reaction_type');
        }
        return $this->success([
            'reaction' => $reaction,
            'reacted' => (bool) $reaction,
            'reactions_count' => $this->reactionCount($record, $publicId),
        ]);
    }

    public function upsert(Request $request, string $post, Outbox $outbox)
    {
        $data = $request->validate([
            'reaction' => 'required|in:like,love,haha,wow,sad,care,pray',
            'actorType' => 'nullable|in:user,page',
            'actorId' => 'nullable|string|max:191',
            'actorName' => 'nullable|string|max:255',
            'actorAvatar' => 'nullable|string|max:2000',
            'actorOwnerId' => 'nullable|string|max:191',
            'pageId' => 'nullable|string|max:191',
        ]);

        $record = $this->post($post);
        $imported = $this->importedPost($post);
        abort_unless($record || $imported, 404, 'Post not found.');

        $publicId = (string) ($record?->firebase_id ?: $post);
        $actorType = (string) ($data['actorType'] ?? 'user');
        $actorId = $this->actorId($request, $data);
        if ($actorType === 'page') $this->authorizePageActor($request, $actorId);

        DB::transaction(function () use ($request, $record, $publicId, $actorId, $actorType, $data, $outbox): void {
            if ($record && $actorType === 'user') {
                DB::table('reactions')->updateOrInsert(
                    ['user_id' => $request->user()->id, 'post_id' => $record->id],
                    ['reaction_type' => $data['reaction'], 'created_at' => now(), 'updated_at' => now()],
                );
            }

            $now = now();
            DB::table('firebase_documents')->updateOrInsert(
                ['collection_path' => 'posts/' . $publicId . '/reactions', 'document_id' => $actorId],
                [
                    'parent_document_path' => 'posts/' . $publicId,
                    'payload' => json_encode([
                        'userId' => (string) ($request->user()->firebase_uid ?: $request->user()->legacy_firebase_uid ?: $request->user()->id),
                        'actorDocId' => $actorId,
                        'actorId' => $actorId,
                        'actorType' => $actorType,
                        'actorOwnerId' => $actorType === 'page' ? (string) ($request->user()->firebase_uid ?: $request->user()->id) : null,
                        'actorName' => (string) ($data['actorName'] ?? $request->user()->name ?? 'Member'),
                        'actorAvatar' => (string) ($data['actorAvatar'] ?? $request->user()->avatar_url ?? ''),
                        'reaction' => $data['reaction'],
                        'postId' => $publicId,
                        'pageId' => $actorType === 'page' ? $actorId : null,
                        'updatedAt' => $now->toISOString(),
                        'updatedAtMs' => $now->getTimestampMs(),
                        'createdAt' => $now->toISOString(),
                        'createdAtMs' => $now->getTimestampMs(),
                    ]),
                    'firebase_updated_at' => $now,
                    'created_at' => $now,
                    'updated_at' => $now,
                ],
            );

            $count = $this->reactionCount($record, $publicId);
            if ($record) {
                DB::table('post_metrics')->updateOrInsert(
                    ['post_id' => $record->id],
                    ['reactions_count' => $count, 'updated_at' => now(), 'created_at' => now()],
                );
            }
            $this->syncPostMirror($publicId, $actorId, true, $count);
            $outbox->record('reaction.updated', 'post', $publicId, [
                'post_id' => $publicId,
                'user_id' => $request->user()->id,
                'actor_id' => $actorId,
                'actor_type' => $actorType,
                'reaction' => $data['reaction'],
                'reactions_count' => $count,
            ]);
        });

        $count = $this->reactionCount($record, $publicId);
        return $this->success(['reaction' => $data['reaction'], 'reacted' => true, 'reactions_count' => $count, 'likes' => $count, 'actor_id' => $actorId]);
    }

    public function destroy(Request $request, string $post, Outbox $outbox)
    {
        $record = $this->post($post);
        $imported = $this->importedPost($post);
        abort_unless($record || $imported, 404, 'Post not found.');
        $publicId = (string) ($record?->firebase_id ?: $post);
        $actorType = (string) $request->input('actorType', 'user');
        $actorId = $this->actorId($request, $request->all());
        if ($actorType === 'page') $this->authorizePageActor($request, $actorId);

        DB::transaction(function () use ($request, $record, $publicId, $actorType, $actorId, $outbox): void {
            if ($record && $actorType === 'user') {
                DB::table('reactions')->where(['user_id' => $request->user()->id, 'post_id' => $record->id])->delete();
            }
            DB::table('firebase_documents')->where([
                'collection_path' => 'posts/' . $publicId . '/reactions',
                'document_id' => $actorId,
            ])->delete();

            $count = $this->reactionCount($record, $publicId);
            if ($record) {
                DB::table('post_metrics')->updateOrInsert(
                    ['post_id' => $record->id],
                    ['reactions_count' => $count, 'updated_at' => now(), 'created_at' => now()],
                );
            }
            $this->syncPostMirror($publicId, $actorId, false, $count);
            $outbox->record('reaction.updated', 'post', $publicId, [
                'post_id' => $publicId,
                'user_id' => $request->user()->id,
                'actor_id' => $actorId,
                'reaction' => null,
                'reactions_count' => $count,
            ]);
        });

        $count = $this->reactionCount($record, $publicId);
        return $this->success(['reaction' => null, 'reacted' => false, 'reactions_count' => $count, 'likes' => $count, 'actor_id' => $actorId]);
    }

    private function post(string $id): ?Post
    {
        return Post::where('id', ctype_digit($id) ? (int) $id : -1)->orWhere('firebase_id', $id)->first();
    }

    private function importedPost(string $id): ?object
    {
        return DB::table('firebase_documents')->where(['collection_path' => 'posts', 'document_id' => $id])->first();
    }

    private function actorId(Request $request, array $data = []): string
    {
        $type = (string) ($data['actorType'] ?? $request->input('actorType', 'user'));
        if ($type === 'page') {
            $id = trim((string) ($data['actorId'] ?? $data['pageId'] ?? $request->input('actorId', $request->input('pageId', ''))));
            abort_unless($id !== '', 422, 'Page actor id is required.');
            return $id;
        }
        return (string) ($request->user()->firebase_uid ?: $request->user()->legacy_firebase_uid ?: $request->user()->id);
    }

    private function authorizePageActor(Request $request, string $pageId): void
    {
        if ($request->user()->isAdmin()) return;
        $owned = DB::table('pages')->where('owner_id', $request->user()->id)->where(function ($q) use ($pageId): void {
            $q->where('firebase_id', $pageId)->orWhere('public_id', $pageId)->orWhere('id', ctype_digit($pageId) ? (int) $pageId : -1);
        })->exists();
        if (! $owned) {
            $row = DB::table('firebase_documents')->where(['collection_path' => 'pages', 'document_id' => $pageId])->first();
            $payload = $row ? $this->payload($row) : [];
            $keys = array_filter([(string) $request->user()->id, (string) $request->user()->firebase_uid, (string) $request->user()->legacy_firebase_uid]);
            $owners = array_filter([(string) ($payload['ownerId'] ?? ''), (string) ($payload['createdBy'] ?? ''), (string) ($payload['userId'] ?? '')]);
            $owned = (bool) array_intersect($keys, $owners);
        }
        abort_unless($owned, 403, 'You cannot act as this page.');
    }

    private function reactionCount(?Post $record, string $publicId): int
    {
        $userCount = $record ? DB::table('reactions')->where('post_id', $record->id)->count() : 0;
        $pageCount = DB::table('firebase_documents')->where('collection_path', 'posts/' . $publicId . '/reactions')
            ->whereRaw("payload->>'actorType' = 'page'")
            ->count();
        if (! $record) {
            return DB::table('firebase_documents')->where('collection_path', 'posts/' . $publicId . '/reactions')->count();
        }
        return $userCount + $pageCount;
    }

    private function syncPostMirror(string $postId, string $actorId, bool $add, int $count): void
    {
        $row = $this->importedPost($postId);
        if (! $row) return;
        $payload = $this->payload($row);
        $likedBy = array_values(array_unique(array_filter((array) ($payload['likedBy'] ?? []), fn ($value) => (string) $value !== $actorId)));
        if ($add) $likedBy[] = $actorId;
        $payload['likedBy'] = array_values(array_unique($likedBy));
        $payload['likes'] = $count;
        $payload['metrics'] = array_merge((array) ($payload['metrics'] ?? []), ['reactions' => $count]);
        $payload['updatedAtMs'] = now()->getTimestampMs();
        DB::table('firebase_documents')->where('id', $row->id)->update(['payload' => json_encode($payload), 'firebase_updated_at' => now(), 'updated_at' => now()]);
    }

    private function payload(object $row): array
    {
        return is_array($row->payload) ? $row->payload : (json_decode((string) $row->payload, true) ?: []);
    }
}
