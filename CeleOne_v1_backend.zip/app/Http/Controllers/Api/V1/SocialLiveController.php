<?php
namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Api\V1\Concerns\ApiResponses;
use App\Services\SocialNotification as N;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
class SocialLiveController extends Controller {
 use ApiResponses;
 public function provision(Request $request) {
  $d=$request->validate(['hostType'=>'required|in:user,page','hostId'=>'required|string|max:191','title'=>'nullable|string|max:160','description'=>'nullable|string|max:1000']);
  $user=$request->user();abort_if($user->firebase_disabled,403);
  $keys=N::keys($user);$uid=(string)($user->firebase_uid ?: $user->legacy_firebase_uid ?: $user->id);
  if($d['hostType']==='page') {
   $host=N::payload(DB::table('firebase_documents')->where(['collection_path'=>'pages','document_id'=>$d['hostId']])->first());
   $allowed=array_intersect($keys,array_filter([$host['ownerId']??null,$host['userId']??null,$host['createdBy']??null]));
   foreach($keys as $key) if(in_array($host['roles'][$key]??'',['owner','admin','editor'],true)) $allowed[]=$key;
   abort_unless($host && $allowed,403,'NOT_PAGE_MANAGER');
   $created=$host['createdAtMs']??$host['createdAt']??null;
  } else {
   abort_unless(in_array($d['hostId'],$keys,true),403,'HOST_MISMATCH');
   $host=['name'=>$user->name,'photoURL'=>$user->avatar_url];
   $created=$user->firebase_created_at ?: $user->created_at;
  }
  if(is_array($created)) $created=($created['seconds']??$created['_seconds']??0)*1000;
  $ms=is_numeric($created)?(float)$created:(strtotime((string)$created)?:0)*1000;
  abort_unless($ms>0 && now()->getTimestampMs()-$ms>=30*86400000,403,'accountTooNew');
  $id=(string)Str::ulid();$name='social_'.$id;$secret=Str::random(48);
  $playback='https://live.celeonetv.com/hls/'.$name.'.m3u8';
  $public=['id'=>$id,'sessionId'=>$id,'hostId'=>$d['hostId'],'hostType'=>$d['hostType'],'hostOwnerId'=>$uid,'hostName'=>$host['name']??$host['displayName']??$user->name,'hostAvatar'=>$host['logoUrl']??$host['photoURL']??$host['profileImage']??'','title'=>$d['title']??$user->name,'description'=>$d['description']??'','playbackUrl'=>$playback,'status'=>'starting','createdAtMs'=>now()->getTimestampMs(),'startedAtMs'=>0,'likes'=>0,'viewerCount'=>0,'commentCount'=>0];
  DB::transaction(function()use($id,$name,$secret,$user,$public){
   DB::table('social_live_credentials')->insert(['session_id'=>$id,'user_id'=>$user->id,'stream_name'=>$name,'secret_hash'=>hash('sha256',$secret),'expires_at'=>now()->addHours(8),'created_at'=>now(),'updated_at'=>now()]);
   DB::table('firebase_documents')->insert(['collection_path'=>'social_live_sessions','document_id'=>$id,'parent_document_path'=>null,'payload'=>json_encode($public),'firebase_updated_at'=>now(),'created_at'=>now(),'updated_at'=>now()]);
  });
  return $this->success(['sessionId'=>$id,'streamKey'=>$name.'?token='.$secret,'rtmpUrl'=>'rtmp://stream.celeonetv.com/live','playbackUrl'=>$playback]);
 }
 public function stop(Request $request) {
  $d=$request->validate(['sessionId'=>'required|string|max:191']);
  $credential=DB::table('social_live_credentials')->where('session_id',$d['sessionId'])->first();
  if(!$credential) return $this->success(['ok'=>true]);
  abort_unless((int)$credential->user_id===(int)$request->user()->id,403);
  $this->end($credential->session_id);
  return $this->success(['ok'=>true]);
 }
 public function callback(Request $request,string $action) {
  $path=config('services.social_live.internal_key_path','/etc/celeone/notification-internal-key');
  $expected=is_readable($path)?trim(file_get_contents($path)):'';
  abort_unless($expected && hash_equals($expected,(string)$request->header('X-Celeone-Internal')),403);
  $name=(string)$request->input('name','');
  abort_unless($request->input('app','live')==='live',403);
  $credential=DB::table('social_live_credentials')->where('stream_name',$name)->where('expires_at','>',now())->first();
  if(!$credential) {
   // Keep the existing TV channel ingest contract.
   $channel=DB::table('firebase_documents')->where('collection_path','channels')->where('payload->streamKey',$name)->exists();
   abort_unless($channel || $action==='done',403);
   return $this->success(['ok'=>true]);
  }
  $secret=(string)$request->input('token','');
  abort_unless(hash_equals($credential->secret_hash,hash('sha256',$secret)),403);
  if($action==='done') $this->end($credential->session_id);
  else {
   $row=DB::table('firebase_documents')->where(['collection_path'=>'social_live_sessions','document_id'=>$credential->session_id])->first();
   $data=N::payload($row);abort_unless($row && in_array($data['status']??'',['starting','live'],true),403);
   $data['status']='live';$data['startedAtMs']=$data['startedAtMs']?:now()->getTimestampMs();
   DB::table('firebase_documents')->where('id',$row->id)->update(['payload'=>json_encode($data),'firebase_updated_at'=>now(),'updated_at'=>now()]);
  }
  return $this->success(['ok'=>true]);
 }
 private function end(string $id): void {
  DB::transaction(function()use($id){
   $row=DB::table('firebase_documents')->where(['collection_path'=>'social_live_sessions','document_id'=>$id])->first();
   if($row){$data=N::payload($row);$data['status']='ended';$data['endedAtMs']=now()->getTimestampMs();DB::table('firebase_documents')->where('id',$row->id)->update(['payload'=>json_encode($data),'firebase_updated_at'=>now(),'updated_at'=>now()]);}
   DB::table('social_live_credentials')->where('session_id',$id)->delete();
   DB::table('social_live_sessions')->where('public_id',$id)->update(['status'=>'ended','updated_at'=>now()]);
  });
 }
}
