<?php
namespace App\Services\Feed;

use App\Models\User;
use Illuminate\Support\Facades\DB;

class FeedInteractions
{
    public function record(User $user, array $events): int
    {
        $audience=new FeedAudience($user);
        $posts=$audience->query()->whereIn('document_id',array_column($events,'postId'))->get(['document_id','feed_tags'])->keyBy('document_id');
        return DB::transaction(function() use($user,$events,$posts): int {
            DB::table('feed_affinities')->insertOrIgnore(['user_id'=>$user->id,'tag_scores'=>'{}','updated_at'=>now()->toIso8601String()]);
            $profile=DB::table('feed_affinities')->where('user_id',$user->id)->lockForUpdate()->first();
            $scores=json_decode($profile->tag_scores,true) ?: [];
            $days=max(0,(now()->getTimestamp()-strtotime($profile->updated_at))/86400);
            $decay=pow(0.98,min(365,$days));
            foreach ($scores as &$score) $score=round((float)$score*$decay,4);
            unset($score);
            $accepted=0;
            foreach ($events as $event) {
                $post=$posts->get($event['postId']);
                if (!$post) continue;
                $type=strtoupper($event['type']);
                $duration=min(300000,max(0,(int)($event['durationMs'] ?? 0)));
                if (($type==='VIEW' || $type==='WATCH') && $duration<2000) continue;
                $inserted=DB::table('feed_interactions')->insertOrIgnore([
                    'user_id'=>$user->id,'event_id'=>$event['eventId'],'post_id'=>$event['postId'],'type'=>$type,'duration_ms'=>$duration,'event_day'=>now()->toDateString(),'created_at'=>now()->toIso8601String(),
                ]);
                if (!$inserted) continue;
                $weight=match($type){'VIEW'=>1,'CLICK'=>3,'LIKE'=>5,'COMMENT'=>6,'SHARE'=>8,'SAVE'=>7,'WATCH'=>min(5,$duration/10000),'SKIP'=>-1,default=>0};
                foreach (json_decode($post->feed_tags ?: '[]',true) ?: [] as $tag) $scores[$tag]=round(min(1000,max(0,($scores[$tag] ?? 0)+$weight)),4);
                $accepted++;
            }
            arsort($scores);
            $scores=array_slice(array_filter($scores,fn($score)=>$score>=0.01),0,100,true);
            DB::table('feed_affinities')->where('user_id',$user->id)->update(['tag_scores'=>json_encode((object)$scores),'updated_at'=>now()->toIso8601String()]);
            return $accepted;
        },3);
    }
}
